from django.db import models

# Create your models here.
class Book:
    def __init__(self, title, author):
        self.title = title
        self.author = author