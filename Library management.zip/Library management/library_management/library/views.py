

# Create your views here.
from django.shortcuts import render , redirect
from .models import Book

books = []

def add_book(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        author = request.POST.get('author')
        new_book = Book(title, author)
        books.append(new_book)
        return redirect('display_books')  
    return render(request, 'add_book.html')

def display_books(request):
    return render(request, 'display_books.html', {'books': books})

def borrow_book(request, book_id):
    del books[book_id]
    return render(request, 'borrow_book.html')
