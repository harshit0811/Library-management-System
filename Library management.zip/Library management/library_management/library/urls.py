# library_management/urls.py
from django.urls import path
from . import views

#app_name = 'library_management'

urlpatterns = [
    path('', views.add_book, name='add_book'),
    path('display_books/', views.display_books, name='display_books'),
    path('borrow_book/<int:book_id>/', views.borrow_book, name='borrow_book'),
    path('display-books/', views.display_books, name='display_books'),
]
